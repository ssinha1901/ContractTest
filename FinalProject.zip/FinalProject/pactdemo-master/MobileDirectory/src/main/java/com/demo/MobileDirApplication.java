package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.HashMap;

@SpringBootApplication
public class MobileDirApplication {
   static HashMap<String, PersonInfo> diary ;
    public static void main(String[] args) {
        diary = new HashMap<>();
        PersonInfo p1 = new PersonInfo("Sumit", 40, "Bangalore");
        PersonInfo p2 = new PersonInfo("Swarna", 37, "Ranchi");
        PersonInfo p3 = new PersonInfo("Akshara", 11, "Pune");
        PersonInfo p4 = new PersonInfo("Aarohi", 3, "Bangalore") ;
        diary.put("9663905050",p1);
        diary.put("7829310484",p2);
        diary.put("9008026890", p3);
        diary.put("9036164516",p4);
        System.out.println("PRINTING THE CONTENTS....");
        diary.forEach((key,value) -> System.out.println(key + " = " + value));

        SpringApplication.run(MobileDirApplication.class, args);
    }
}

