package com.demo;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Random;

import static com.demo.MobileDirApplication.diary;

@RestController
public class MobileDirController {

    @RequestMapping("/find/{mobileNum}")
    public PersonInfo find(@PathVariable String mobileNum) {

        return( getPersonDetails(mobileNum));

    }


    private PersonInfo getPersonDetails(String mobileNum) {
        System.out.println("Retreiving details for: " +mobileNum);
        return (diary.get(mobileNum));


    }
}
