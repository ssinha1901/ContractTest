package com.client;

import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

public class GetPersonDetails {
    int port=8080;

    public GetPersonDetails(int port) {
        this.port = port;

        System.out.println("Custom port "+port);
    }

    public GetPersonDetails() {
        System.out.println("Default port "+port);

    }

    public static void main( String[] args ) {
        GetPersonDetails gpd = new GetPersonDetails();
        gpd.getDetails("9663905050");
    }
    public int getDetails(String mobileNum) {
        try {
            String url=String.format("Http://localhost:%d/find/%s", port, mobileNum);
            System.out.println("using URL: "+url);
            HttpResponse r = Request.Get(url).execute().returnResponse();
            String json = EntityUtils.toString(r.getEntity());
            System.out.println("json response ="+json);
            JSONObject jsonObject = new JSONObject(json);
            String name = jsonObject.get("name").toString();
            System.out.print("Name: " +name);
            return 0;

        }
        catch (Exception e) {
            System.out.println("Unable to get details");
            e.printStackTrace();
            return -1 ;
        }
    }
}
